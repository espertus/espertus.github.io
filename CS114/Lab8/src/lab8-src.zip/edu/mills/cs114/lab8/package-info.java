/**
 * The classes necessary for CS 114/214 Lab 8, in which
 * students modify an NFA solver so it is multi-threaded
 * instead of single-threaded.
 * 
 * @author Ellen Spertus
 */
package edu.mills.cs114.lab8;

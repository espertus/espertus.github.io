package edu.mills.cs122.lab6;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

/**
 * Tests of {@link NruReplacementScheme}.
 * 
 * @author Ellen Spertus (spertus@mills.edu)
 */
public class NruReplacementSchemeTest {
	final static int NUM_FRAMES = 4;
	static NruReplacementScheme rs;

	@Before
	public void setUp() throws Exception {
		rs = new NruReplacementScheme(NUM_FRAMES);
	}
	
	@Test
	public void testSelectionOfFrames() {
		// Allocate all frames once.
		for (int i = 0; i < NUM_FRAMES; i++) {
			rs.registerLoadToFrame(i);
			rs.registerAccessToFrame(i);
		}
		
		// Access all but the last frame.
		for (int i = 0; i < NUM_FRAMES - 1; i++) {
			rs.registerAccessToFrame(i);
		}
		
		// Ensure that suggested frame to replace is the last one.
		assertEquals(NUM_FRAMES - 1, rs.getFrameToReplace());
	}
}

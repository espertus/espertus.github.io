package edu.mills.cs122.lab6;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Test;

/**
 * Tests of {@link PageTable}.
 * 
 * @author Ellen Spertus (spertus@mills.edu)
 */
public class PageTableTest {
	private static final int PAGE_SIZE = 1024;
	private static final int NUM_PAGES = 16;
	private static final int NUM_FRAMES = 4;

	@Test
	public void testGetBaseTwoLog() {
		// Test positive powers of two.
		assertEquals(0, PageTable.getBaseTwoLog(1));
		assertEquals(1, PageTable.getBaseTwoLog(2));
		assertEquals(2, PageTable.getBaseTwoLog(4));
		assertEquals(5, PageTable.getBaseTwoLog(32));
		
		// Test that non-positive arguments are rejected with IllegalArgumentException.
		try {
			PageTable.getBaseTwoLog(0);
			fail();
		} catch (IllegalArgumentException e) {
			// should fail
		}
		try {
			PageTable.getBaseTwoLog(-1);
			fail();
		} catch (IllegalArgumentException e) {
			// should fail
		}
		
		// Test that getBaseTwoLog rounds down.
		assertEquals(1, PageTable.getBaseTwoLog(3));
		assertEquals(4, PageTable.getBaseTwoLog(17));
		assertEquals(4, PageTable.getBaseTwoLog(31));
	}
	
	@Test
	public void testAddressToPageNumber() {
		final PageTable pageTable = new PageTable(PAGE_SIZE, NUM_PAGES, NUM_FRAMES,
				new RandomReplacementScheme(NUM_FRAMES));
		
		// Test legal values.
		for (int i = 0; i < NUM_PAGES; i++) {
			// Test value at very beginning of page.
			assertEquals(i, pageTable.addressToPageNumber(i * PAGE_SIZE));
			// Test value in middle of page.
			assertEquals(i, pageTable.addressToPageNumber(i * PAGE_SIZE + PAGE_SIZE / 2));
			// Test value at very end of page.
			assertEquals(i, pageTable.addressToPageNumber((i + 1) * PAGE_SIZE - 1));
		}
		
		// Negative addresses should fail.
		try {
			pageTable.addressToPage(-1);
			fail();
		} catch (IllegalArgumentException e) {
			// This is the correct behavior.
		}
		try {
			pageTable.addressToPage(Integer.MIN_VALUE);
			fail();
		} catch (IllegalArgumentException e) {
			// This is the correct behavior.
		}
		
		// Too large of addresses should fail.
		try {
			pageTable.addressToPage(NUM_PAGES * PAGE_SIZE);
			fail();
		} catch (IllegalArgumentException e) {
			// This is the correct behavior.
		}
		try {
			pageTable.addressToPage(Integer.MAX_VALUE);
			fail();
		} catch (IllegalArgumentException e) {
			// This is the correct behavior.
		}		
	}
	
	@Test
	public void testAddressToOffset() {
		final PageTable pageTable = new PageTable(PAGE_SIZE, NUM_PAGES, NUM_FRAMES,
				new RandomReplacementScheme(NUM_FRAMES));
		
		// Test legal values, including addresses that do not map to legal pages
		// (since the offsets can still be computed).
		for (int i = 0; i < NUM_PAGES * 2; i++) {
			// Test value at very beginning of page.
			assertEquals(0, pageTable.addressToOffset(i * PAGE_SIZE));
			// Test value in middle of page.
			assertEquals(PAGE_SIZE / 2, pageTable.addressToOffset(i * PAGE_SIZE + PAGE_SIZE / 2));
			// Test value at very end of page.
			assertEquals(PAGE_SIZE - 1, pageTable.addressToOffset((i + 1) * PAGE_SIZE - 1));
		}
		
		// Negative addresses should fail.
		try {
			pageTable.addressToOffset(-1);
			fail();
		} catch (IllegalArgumentException e) {
			// This is the correct behavior.
		}
		try {
			pageTable.addressToOffset(Integer.MIN_VALUE);
			fail();
		} catch (IllegalArgumentException e) {
			// This is the correct behavior.
		}
		
		// Too large of addresses should fail.
		try {
			pageTable.addressToPage(NUM_PAGES * PAGE_SIZE);
			fail();
		} catch (IllegalArgumentException e) {
			// This is the correct behavior.
		}
		try {
			pageTable.addressToPage(Integer.MAX_VALUE);
			fail();
		} catch (IllegalArgumentException e) {
			// This is the correct behavior.
		}	
	}
}

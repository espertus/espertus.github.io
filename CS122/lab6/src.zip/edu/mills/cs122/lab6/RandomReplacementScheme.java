package edu.mills.cs122.lab6;

/**
 * A replacement scheme for a {@link PageTable}.  When suggesting a frame to replace, 
 * this returns the first invalid frame, if any exists, or a random valid one.
 * 
 * @author Ellen Spertus (spertus@mills.edu)
 */
public class RandomReplacementScheme extends ReplacementScheme {
	public RandomReplacementScheme(int numFrames) {
		super(numFrames);
	}

	@Override
	public int getFrameToReplace() {
		int frame = getFirstInvalidFrame();
		return (frame >= 0) ? frame : (int) (Math.random() * numFrames);
	}
}

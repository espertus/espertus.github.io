package edu.mills.cs122.lab6;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

/**
 * Tests of {@link Page}.
 * 
 * @author Ellen Spertus (spertus@mills.edu)
 */
public class PageTest {
	private final static int PAGE_SIZE = 1024;
	private Page page;
	
	@Before
	public void setUp() {
		page = new Page(PAGE_SIZE);
	}
	
	@Test
	public void testConstructor() {
		// Make sure initial contents are all 0.
		for (int i = 0; i < PAGE_SIZE; i++) {
			assertEquals(0, page.read(i));
		}
	}
	
	@Test
	public void testWrite()  {
		// Write a legal locations and check internal representation.
		byte b = 50;
		int address = 1;
		page.write(address, b);
		assertEquals(b, page.read(address));
		
		// Check that no other locations have changed their values.
		for (int i = 0; i < PAGE_SIZE; i++) {
			if (i != address) {
				assertEquals(0, page.read(i));
			}
		}
		
		// Check that illegal offsets cause ArrayIndexOutOfBoundsException.
		try {
			page.write(-1, b);
			fail();
		} catch (ArrayIndexOutOfBoundsException e) {
			// This is the correct behavior.
		}
		try {
			page.write(PAGE_SIZE, b);
			fail();
		} catch (ArrayIndexOutOfBoundsException e) {
			// This is the correct behavior.
		}
	}
	
	@Test
	public void testRead()  {
		// Write a legal location and check that we can read it back.
		byte b = 50;
		int address = 1;
		page.write(address, b);
		assertEquals(b, page.read(address));
		
		// Check that illegal offsets cause ArrayIndexOutOfBoundsException.
		try {
			page.read(-1);
			fail();
		} catch (ArrayIndexOutOfBoundsException e) {
			// This is the correct behavior.
		}
		try {
			page.read(PAGE_SIZE);
			fail();
		} catch (ArrayIndexOutOfBoundsException e) {
			// This is the correct behavior.
		}
	}
}

package edu.mills.cs122.lab6;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * A textual interface for a memory simulator.
 * 
 * @author Ellen Spertus (spertus@mills.edu)
 */
public class UserInterface {
	private static PageTable pageTable;

	/**
	 * Prints instructions on the format of commands to access pages.
	 */
	private static void printInstructions() {
		System.out.println("Enter commands in one of the following three formats: ");
		System.out.println("\tr <address> [to read a byte from the specified address]");
		System.out.println("\tw <address> <value> [to write the specified byte value to the address");
		System.out.println("\tq [to quit]");
	}

	private static void doRead(String[] tokens) {
		if (tokens.length != 2) {
			printInstructions();
			return;
		}
		try {
			int address = Integer.parseInt(tokens[1]);
			System.out.println(pageTable.addressToPage(address).read(pageTable.addressToOffset(address)));
		} catch (NumberFormatException e) {
			System.err.println("Number expected in place of " + tokens[1]);
		} catch (IllegalArgumentException e) {
			System.err.println(e.getMessage());
		} catch (ArrayIndexOutOfBoundsException e) {
			System.err.println(e.getMessage());
		}
	}

	private static void doWrite(String[] tokens) {
		if (tokens.length != 3) {
			printInstructions();
			return;
		}
		try {
			int address = Integer.parseInt(tokens[1]);		
			byte b = Byte.parseByte(tokens[2]);
			pageTable.addressToPage(address).write(pageTable.addressToOffset(address), b);
			return;
		} catch (NumberFormatException e) {
			// The default message for NumberFormatException 
			System.err.println("Illegal value entered where a number was expected.");
		} catch (IllegalArgumentException e) {
			System.err.println(e.getMessage());
		} catch (ArrayIndexOutOfBoundsException e) {
			System.err.println(e.getMessage());
		}
	}

	static boolean isPowerOfTwo(int num) {
		return (num & (num - 1)) == 0;
	}

	/**
	 * Provides the user interface to a simulated virtual memory
	 * system.  First, this solicits a page size (which must be a power
	 * of two) and a number of pages to create.  Then, a loop allows
	 * users to read from or write to a page or to quit the program.
	 * 
	 * @param args unused
	 */
	public static void main(String args[]) {
		// Prepare to receive input from keyboard.
		Scanner scanner = new Scanner(System.in);

		try {
			// Solicit page size from user, repeating until a positive power
			// of two is entered.  The value is used to initialize the static
			// variables pageSize and lgPageSize through setPageSize().
			while (true) {
				try {
					// Get and validate page size.
					System.out.print("Enter page size in bytes: ");
					int pageSize = scanner.nextInt();  // could throw InputMismatchException
					scanner.nextLine();
					if (pageSize < 1 || !isPowerOfTwo(pageSize)) {
						System.err.println("Page size must be a positive power of two.");
						continue;
					}

					// Get and validate number of pages.
					System.out.println("Enter number of pages to create: ");
					int numPages = scanner.nextInt();  // could throw InputMismatchException
					scanner.nextLine();
					if (numPages < 1) {
						System.err.println("Number of pages must be at least 1.");
						continue;
					}

					// Get and validate number of frames.
					System.out.println("Enter number of frames: ");
					int numFrames = scanner.nextInt();  // could throw InputMismatchException
					scanner.nextLine();
					if (numFrames < 1) {
						System.err.println("Number of frames must be at least 1.");
						continue;
					}

					// Get and validate replacement scheme.
					ReplacementScheme rs = null;
					while (rs == null) {
						System.out.print("Specify a replacement scheme by number (1: random, 2: FIFO, 3: NRU): ");
						int scheme = scanner.nextInt();   // could throw InputMismatchException
						scanner.nextLine(); // consume the rest of the line

						switch(scheme) {
						case 1:
							rs = new RandomReplacementScheme(numFrames);
							break;
						case 2:
							rs = new FifoReplacementScheme(numFrames);
							break;
						case 3:
							rs = new NruReplacementScheme(numFrames);
							break;
						default:
							System.err.println("Not a legal choice for replacement scheme.");
							break;
						}
					}

					// Create the page table.
					pageTable = new PageTable(pageSize, numPages, numFrames, rs);
					break;
				} catch (IllegalArgumentException e) {
					// This should not be possible, since we validate the arguments to
					// the PageTable constructor before calling it.
					throw new AssertionError(e);
				} catch (InputMismatchException e) {
					// This occurs if a number was not entered where expected.
					System.err.println("Please enter an integer.");
					scanner.nextLine();  // Consume the bad input.
				}
			}
			printInstructions();

			// Main loop of program, exited when user enters 'q'.
			for (;;) {
				System.out.print("Enter command: ");
				String line = scanner.nextLine().trim();
				if (line.isEmpty()) {
					continue;
				}
				String[] tokens = line.split(" ");
				if (line.charAt(0) == 'q') {
					break;
				} else if (line.charAt(0) == 'r') {
					doRead(tokens);
				} else if (line.charAt(0) == 'w') {
					doWrite(tokens);
				} else {
					System.err.println("Illegal input.");
				}
			}
		} finally {
			scanner.close();
		}

		System.out.println("Number of page loads: " + pageTable.getNumMisses());
		System.out.println("Number of page accesses: " + pageTable.getNumAccesses());
		if (pageTable.getNumAccesses() > 0) {
			System.out.println("Miss rate: " + (pageTable.getNumMisses() / pageTable.getNumAccesses()));
		}
	}
}

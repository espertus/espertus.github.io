package edu.mills.cs122.lab6;

/**
 * An abstract representation of a page table replacement scheme.  Clients
 * should call {@link #getFrameToReplace()} when they need to select a frame
 * into which to load a page.  This will either return the first invalid frame,
 * if one is available, or the result of {@link #getFrameToReplace()}.  
 * 
 * <p>When loading a page into a frame, the client must call 
 * {@link #registerLoadToFrame(int)}, and the client must call
 * {@link #registerAccessToFrame(int)} whenever accessing the frame 
 * (including the first time).  While these two calls provide no immediate 
 * benefit to the client, they enable the scheme to keep track of frame usage 
 * and to keep the usage statistics accessible with {@link #getNumAccesses()} 
 * and {@link #getNumPageReplacements()}.
 * 
 * @author Ellen Spertus (spertus@mills.edu)
 */
public abstract class ReplacementScheme {
	protected int numFrames;
	private boolean[] valid;  // one entry per frame
	private int numAccesses;
	private int numPageReplacements;
	
	/**
	 * Constructor of a replacement scheme managing the specified
	 * number of frames.
	 * 
	 * @param numFrames the number of frames to keep track of
	 */
	public ReplacementScheme(int numFrames) {
		this.numFrames = numFrames;
		valid = new boolean[numFrames];
		numAccesses = 0;
		numPageReplacements = 0;
	}
	
	/**
	 * Registers that the specified frame is being loaded with new contents.
	 * This erases the past history (for LRU, MRU, etc.) and sets the time
	 * loaded (for FIFO, LIFO, etc.).
	 * 
	 * @param frame the index of the frame being loaded with new contents.
	 */
	public void registerLoadToFrame(int frame) {
		valid[frame] = true;
		numPageReplacements++;
	}
	
	/**
	 * Registers that the specified frame was accessed (whether due to a hit 
	 * or a load).  This is useful for implementing LRU, MRU, and NRU.
	 * 
	 * @param frame the index of the accessed frame
	 */
	public void registerAccessToFrame(int frame) {
		numAccesses++;
	}
	
	/**
	 * Returns the index of the frame whose contents should be replaced.
	 * Implementations should return the index of an invalid frame, if any exist.
	 * Otherwise, the result depends on the replacement strategy.  The history
	 * of the frame should not be affected by this call.
	 *
	 * @return the index of the frame whose contents should be replaced
	 */
	public abstract int getFrameToReplace();
	
	/**
	 * Returns the index of the numerically first frame that is not valid,
	 * or -1 if all frames are valid.
	 * 
	 * @return the index of the numerically first frame that is not valid,
	 *         or -1 if all frames are valid
	 */
	protected int getFirstInvalidFrame() {
		for (int i = 0; i < numFrames; i++) {
			if (!valid[i]) {
				return i;
			}
		}
		return -1;
	}
	
	/**
	 * Returns the number of successful accesses of data in this page table (the
	 * number of calls to {@link #registerAccessToFrame(int)}).
	 * 
	 * @return the number of successful accesses of data in this page table
	 */
	public int getNumAccesses() {
		return numAccesses;
	}
	
	/**
	 * Returns the number of times frames have had to be loaded since creation of
	 * this {@code ReplacementScheme}.
	 * 
	 * @return the number of times frames have had to be loaded
	 */
	public int getNumPageReplacements() {
		return numPageReplacements;
	}
}

package edu.mills.cs122.lab6;

import java.util.LinkedList;

/**
 * A first-in first-out replacement scheme for a {@link PageTable}.
 * When suggesting a frame to replace, this returns the first invalid
 * frame, if any exists, or the frame that was loaded earliest.
 * 
 * @author Ellen Spertus (spertus@mills.edu)
 */
public class FifoReplacementScheme extends ReplacementScheme {
	private LinkedList<Integer> framesOrderedByLoadTime;
	
	/**
	 * Create a first-in first-out replacement scheme for the specified 
	 * number of frames.
	 * 
	 * @param numFrames the number of frames
	 */
	public FifoReplacementScheme(int numFrames) {
		super(numFrames);
		framesOrderedByLoadTime = new LinkedList<Integer>();
	}

	@Override
	public void registerLoadToFrame(int frame) {
	  super.registerLoadToFrame(frame);
		// This frame must either have been invalid, in which case it was not in the queue,
		// or valid, in which case it is at the head of the linked list and should be removed from there.
		if (!framesOrderedByLoadTime.isEmpty() && framesOrderedByLoadTime.getFirst().equals(frame)) {
			framesOrderedByLoadTime.remove();
		} else {
			assert !framesOrderedByLoadTime.contains(frame);
		}

		// In any event, the frame number must be added to the end of the queue.
		framesOrderedByLoadTime.addLast(frame);
	}
	
	@Override
	public int getFrameToReplace() {
		int frame = getFirstInvalidFrame();
		if (frame >= 0) {
			// An invalid frame was found.
			return frame;
		}
		// If all frames are valid, the linked list must have exactly numFrames elements
		// and thus cannot be empty.
		assert !framesOrderedByLoadTime.isEmpty();
		return framesOrderedByLoadTime.getFirst();
	}
}

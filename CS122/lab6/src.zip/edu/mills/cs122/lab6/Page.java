package edu.mills.cs122.lab6;

/**
 * A page in a virtual memory system.
 * 
 * @author Ellen Spertus (spertus@mills.edu)
 */
public class Page {
	byte[] storage;

	/**
	 * Constructs a page of the specified size with initial contents of 0.
	 * 
	 * @param pageSize the page size in bytes
	 */
	public Page(int pageSize) {
		storage = new byte[pageSize];
	}

	/**
	 * Reads a byte from this page.
	 * 
	 * @param offset the offset from which to read
	 * @return the value at the specified offset
	 * @throws ArrayIndexOutOfBoundsException if {@code offset} is not within the page
	 */
	public byte read(int offset) {
		return storage[offset];   // may throw ArrayIndexOutOfBoundsException
	}

	/**
	 * Writes a byte to this page.
	 * 
	 * @param offset the offset at which to write
	 * @param b the value to write
	 * @throws ArrayIndexOutOfBoundsException if {@code offset} is not within the page
	 */
	public void write(int offset, byte b) {
		storage[offset] = b;   // may throw ArrayIndexOutOfBoundsException
	}
}






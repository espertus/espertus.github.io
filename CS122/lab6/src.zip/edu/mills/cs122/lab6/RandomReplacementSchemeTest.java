package edu.mills.cs122.lab6;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

/**
 * Tests of {@link RandomReplacementScheme}.
 * 
 * @author Ellen Spertus (spertus@mills.edu)
 */
public class RandomReplacementSchemeTest {
	final static int NUM_FRAMES = 4;
	static RandomReplacementScheme rs;

	@Before
	public void setUp() throws Exception {
		rs = new RandomReplacementScheme(NUM_FRAMES);
	}
	
	@Test
	public void testSelectionOfInvalidFrames() {
		// Initially, frame 0 should be suggested.
		assertEquals(0, rs.getFrameToReplace());
		assertEquals(0, rs.getFrameToReplace());
		assertEquals(0, rs.getFrameToReplace());
		
		// Frames should be suggested sequentially as earlier ones are used.
		for (int i = 0; i < NUM_FRAMES - 1; i++) {
			rs.registerLoadToFrame(i);
			assertEquals(i + 1, rs.getFrameToReplace());
		}	
	}
	
	@Test
	public void testSelectionOfValidFrames() {
		// Allocate all frames once.
		for (int i = 0; i < NUM_FRAMES; i++) {
			rs.registerLoadToFrame(i);
		}
		
		// Any frame in the range 0..(NUM_FRAMES - 1) can now be suggested.
		int numTrials = 100;
		for (int i = 0; i < numTrials; i++) {
			int frame = rs.getFrameToReplace();
			assertTrue(frame >= 0 && frame < NUM_FRAMES);
		}
	}
}

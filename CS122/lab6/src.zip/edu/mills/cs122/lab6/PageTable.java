package edu.mills.cs122.lab6;


/**
 * A high-level representation of a page table.
 * 
 * @author Ellen Spertus (spertus@mills.edu)
 */
public class PageTable {
	// an entry in a page table mapping a page to a frame
	static class Entry {
		boolean valid = false;
		int frameNum;  // do not read this if !valid
	}
	
	// represents a frame holding the specified page
	static class Frame {
		static final int NO_PAGE = -1;

		int pageNum = NO_PAGE;
	}
	
	private int pageSize;
	private int lgPageSize;
	private int numFrames;
	private ReplacementScheme replacementScheme;
	private Page[] pages;
	private Frame[] frames;
	private Entry[] entries;
	private int numAccesses = 0;
	private int numMisses = 0;

	/**
	 * Constructor for a simulated page table for the specified memory configuration.
	 * 
	 * @param pageSize number of byte addresses per page/frame
	 * @param numPages number of pages in the logical address space
	 * @param numFrames number of frames in the physical address space
	 * @param replacementScheme scheme to decide which frame to replace when bringing in
	 *        a page from secondary storage
	 * @throws IllegalArgumentException if {@code pageSize} is not a positive power of two
	 *         or if any of the {@code int} arguments are not positive.                 
	 */
	public PageTable(int pageSize, int numPages, int numFrames, ReplacementScheme replacementScheme) {
		// Validate arguments.
		if (pageSize <= 0 || numPages <= 0 || numFrames <= 0) {
			throw new IllegalArgumentException("pageSize, numPages, and numFrames must all be positive.");
		}
		
		// Make sure pageSize is a positive power of two and set lgPageSize.
		lgPageSize = getBaseTwoLog(pageSize);
		if ((1 << lgPageSize) != pageSize) {
			throw new IllegalArgumentException(pageSize + " is not a positive power of two.");
		}
		
		// Set non-array instance variables.
		this.pageSize = pageSize;
		this.numFrames = numFrames;
		this.replacementScheme = replacementScheme;
		
		// Create and allocate pages and entries in the page table.
		pages = new Page[numPages];
		entries = new Entry[numPages];
		for (int i = 0; i < numPages; i++) {
			pages[i] = new Page(pageSize);
			entries[i] = new Entry();
		}
		
		// Create frames.
		frames = new Frame[this.numFrames];
		for (int i = 0; i < this.numFrames; i++) {
			frames[i] = new Frame();
		}
	}

	/**
	 * Returns the floor of the base-two logarithm of the argument.
	 * 
	 * @param num the number whose logarithm to find
	 * @return the floor of the base-two logarithm
	 * @throws IllegalArgumentException if the argument is not positive.
	 */
	static int getBaseTwoLog(int num) throws IllegalArgumentException {
		if (num < 1) {
			throw new IllegalArgumentException("Argument " + num + " must be positive.");
		}
		int log = 0;
		while (num > 1) {
			log++;
			num = num >> 1;
		}
		return log;
	}
	
	int addressToPageNumber(int address) throws IllegalArgumentException {
		if (address < 0) {
			throw new IllegalArgumentException("Address must be positive.");
		}
		int pageNum = address >>> lgPageSize;
		if (pageNum < 0 || pageNum >= pages.length) {
			throw new IllegalArgumentException("Address " + address + " would be on page " + pageNum
					+ ", which doesn't exist.");
		}
		return pageNum;
	}
	
	/**
	 * Returns the page corresponding to the given address.
	 * 
	 * @param address, which must be non-negative
	 * @return the corresponding page
	 * @throws IllegalArgumentException if {@code address} is negative or does not correspond to a legal page
	 */
	Page addressToPage(int address) {
		return getPage(addressToPageNumber(address));
	}
	
	/**
	 * Returns the offset for the given address, which must be positive.  This does
	 * not check if a page exists corresponding to the address.
	 * 
	 * @param address the address
	 * @return the offset
	 * @throws IllegalArgumentException if {@code address} is negative
	 */
	int addressToOffset(int address) {
		if (address < 0) {
			throw new IllegalArgumentException("Address must be positive.");
		}
		return address & (pageSize - 1);
	}
	
	/**
	 * Reports that the specified page is being accessed.  This increments the
	 * number of accesses and possibly the number of misses.
	 * 
	 * @param pageNum the page to access
	 * @return the requested page
	 */
	public Page getPage(int pageNum) {
		numAccesses++;
		Entry entry = entries[pageNum];
		if (entry.valid) {
			// Hit!
			replacementScheme.registerAccessToFrame(entry.frameNum);
			return pages[frames[entry.frameNum].pageNum];
		}
		// Miss!  Choose a frame to use for this page.
		numMisses++;
		int frameNum = replacementScheme.getFrameToReplace();
		Frame frame = frames[frameNum];
		
		// If a page had been stored in this frame, kick it out.
		if (frame.pageNum != Frame.NO_PAGE) {
			// In a real system, we would store the page onto disk.
			// Update the page table entry for that unlucky page.
			entries[frame.pageNum].valid = false;
		}
		
		// Now, put the requested page in the appropriate frame.
		frame.pageNum = pageNum;  // In a real system, we would bring in from disk.
		replacementScheme.registerLoadToFrame(frameNum);
		
		// Update the page table entry.
		entry.frameNum = frameNum;
		entry.valid = true;
		
		// Now that the page is in a frame, return it to client.
		replacementScheme.registerAccessToFrame(frameNum);
		return pages[frame.pageNum];
	}
	
	/**
	 * Returns the number of accesses (the number of calls to {@link #getPage(int)}).
	 * 
	 * @return the number of accesses
	 */
	public int getNumAccesses() {
		return numAccesses;
	}
	
	/**
	 * Returns the number of misses (the number of calls to {@link #getPage(int)}
	 * that caused a frame to be refilled).
	 * 
	 * @return the number of misses
	 */
	public int getNumMisses() {
		return numMisses;
	}
}

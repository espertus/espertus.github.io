package edu.mills.cs122.lab6;


/**
 * A not recently used (NRU) replacement scheme that maintains a referenced 
 * bit for each frame, which it sets when the frame is accessed.  Every <em>n</em> accesses, 
 * all of the referenced bits are reset (including the most recent one), where 
 * <em>n</em> is one less than numFrames.  When it is time to pick a page to replace, 
 * any of the frames not accessed since the last reset may be chosen.
 * 
 * @author Ellen Spertus (spertus@mills.edu)
 *
 */
public class NruReplacementScheme extends ReplacementScheme {
	static int timeUntilNextReset;
	static boolean[] accessedRecently;

	public NruReplacementScheme(int numFrames) {
		super(numFrames);
		timeUntilNextReset = numFrames - 1;
		accessedRecently = new boolean[numFrames];  // initial values of false
	}

	@Override
	public void registerAccessToFrame(int frameNum) {
	  super.registerAccessToFrame(frameNum);
		// If the time has come, clear all information about recent accesses.
		if (timeUntilNextReset-- == 0) {
			for (int i = 0; i < numFrames; i++) {
				accessedRecently[i] = false;
			}
			timeUntilNextReset = numFrames - 1;
		} else {
			// Mark that the current frame has been recently accessed.
			accessedRecently[frameNum] = true;
		}
	}

	@Override
	public int getFrameToReplace() {
		// This chooses the earliest frame that has not been accessed recently,
		// but that is not specified in the API for the class, so could change.
		for (int i = 0; i < numFrames; i++) {
			if (!accessedRecently[i]) {
				return i;
			}
		}
		assert false;  // This line can only be reached on programmer error.
		return 0;
	}

}
